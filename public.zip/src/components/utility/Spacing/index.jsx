import React from "react"

const Spacing = ({ height }) => {
	return <div style={{ height: height }}></div>
}

export default Spacing
