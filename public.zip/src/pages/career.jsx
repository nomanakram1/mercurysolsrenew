import React from "react"
import LayoutWrapper from "components/layout/LayoutWrapper"
import {  Container } from "react-bootstrap"


const Careerpage = () => {
	return (
		<>
		<LayoutWrapper>
			<Container>
				<h2>Career page works...</h2>
				
			</Container>
		</LayoutWrapper>
			
		</>
	)
}

export default Careerpage;
