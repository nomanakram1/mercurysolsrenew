import React from "react"

export const content_home = {
	pageTitle: "Homepage",

	hero: {
		title: "Hero title goes here",
		button: {
			text: "Contact us",
			path: "/contact",
		},
	},
}
