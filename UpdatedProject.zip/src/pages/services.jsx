import React from "react"
import LayoutWrapper from "components/layout/LayoutWrapper"
import {  Container } from "react-bootstrap"

const Servicespage = () => {
	return (
		<>
		<LayoutWrapper>
			<Container>
				<h2>Services page works...</h2>
			</Container>
		</LayoutWrapper>
			
		</>
	)
}

export default Servicespage
