import React from "react"
import LayoutWrapper from "components/layout/LayoutWrapper"
import { Button, Container, Col, Row } from "react-bootstrap"
// import Hero from "components/base/Hero"

const Aboutpage = () => {
	return (
		<>
			<LayoutWrapper>
				<Container>
					<Row>
						<Col>
							<div>About page works...</div>
						</Col>
					</Row>
				</Container>
			</LayoutWrapper>
		</>
	)
}
export default Aboutpage
