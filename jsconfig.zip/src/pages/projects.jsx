import React from "react"
import LayoutWrapper from "components/layout/LayoutWrapper"
import {  Container } from "react-bootstrap"
const Projectpage = () => {
	return (
		<>
		<LayoutWrapper>
			<Container>
				<h2>Projetc page works...</h2>
			</Container>
		</LayoutWrapper>
			
		</>
	)
}

export default Projectpage;