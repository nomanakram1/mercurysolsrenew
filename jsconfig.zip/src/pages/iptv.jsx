import React from "react"
import LayoutWrapper from "components/layout/LayoutWrapper"
import {  Container } from "react-bootstrap"
const Iptvpage = () => {
	return (
		<>
			<LayoutWrapper>
			<Container>
				<h2>Iptv page works...</h2>
			</Container>
		</LayoutWrapper>
		</>
	)
}

export default Iptvpage
